from typing import Tuple, List, Union, Optional
from typing_extensions import Literal

from config import Config


class Dataset(Config):
    name: str
    n_samples: int = None
    select_views: Tuple[int, ...] = None
    select_labels: Tuple[int, ...] = None
    label_counts: Tuple[int, ...] = None
    noise_sd: float = None
    noise_views: Tuple[int, ...] = None


class Loss(Config):
    n_clusters: int = None
    funcs: str
    weights: Tuple[Union[float, int], ...] = None
    rel_sigma = 0.15
    tau = 0.1
    delta = 0.1
    negative_samples_ratio: float = 0.25
    contrastive_similarity: Literal["cos", "gauss"] = "cos"
    adaptive_contrastive_weight = True
    c1 = 0.1
    c2 = 0.1


class Optimizer(Config):
    learning_rate: float = 0.001
    clip_norm: float = 5.0
    scheduler_step_size: int = None
    scheduler_gamma: float = 0.1


class DDC(Config):
    n_clusters: int = None
    n_hidden = 100
    use_bn = True


class CNN(Config):
    input_size: Tuple[int, ...] = None
    layers = (
        ("conv", 5, 5, 32, "relu"),
        ("conv", 5, 5, 32, None),
        ("bn",),
        ("relu",),
        ("pool", 2, 2),
        ("conv", 3, 3, 32, "relu"),
        ("conv", 3, 3, 32, None),
        ("bn",),
        ("relu",),
        ("pool", 2, 2),
    )

class resnet(Config):
    block: Literal["BasicBlock", "weighted_mean"]

class vgg(Config):
    block: Literal["BasicBlock", "weighted_mean"]

class MLP(Config):
    input_size: Tuple[int, ...] = None
    layers: Tuple[Union[int, str], ...] = (512, 512, 256)
    activation: Union[str, None, List[Union[None, str]], Tuple[Union[None, str], ...]] = "relu"
    use_bias: Union[bool, Tuple[bool, ...]] = True
    use_bn: Union[bool, Tuple[bool, ...]] = False


class Fusion(Config):
    method: Literal["mean", "weighted_mean"]
    n_views: int


class DDCModel(Config):
    backbone_config: Union[MLP, CNN]
    cm_config: Union[DDC]
    loss_config: Loss
    optimizer_config = Optimizer()


class PGCLDCL(Config):
    backbone_configs: Tuple[Union[vgg, MLP, CNN], ...]
    projector_config: Optional[MLP]
    fusion_config: Fusion
    cm_config: Union[DDC]
    loss_config: Loss
    optimizer_config = Optimizer()


class Experiment(Config):
    dataset_config: Dataset
    model_config: Union[PGCLDCL, DDC]
    n_runs = 20
    n_epochs = 100
    batch_size = 100
    eval_interval: int = 4
    checkpoint_interval = 20
    patience = 50000
    n_eval_samples: int = None
    best_loss_term = "ddc_1"
    seed = 0

import torch as th
import torch.nn as nn
import numpy as np
import config
from lib import kernel
import math
import torch.distributions.normal as normal
import torch.nn.functional as F
from lib.mutual_information import mutual_information
from torch.distributions import Normal, Independent
from torch.nn.functional import softplus
from lib import contrastive_loss
EPSILON = 1E-9
DEBUG_MODE = False
device = th.device("cuda" if th.cuda.is_available() else "cpu")

def triu(X):

    return th.sum(th.triu(X, diagonal=1))

def _atleast_epsilon(X, eps=EPSILON):
    return th.where(X < eps, X.new_tensor(eps), X)


def d_cs(A, K, n_clusters):

    nom = th.t(A) @ K @ A
    dnom_squared = th.unsqueeze(th.diagonal(nom), -1) @ th.unsqueeze(th.diagonal(nom), 0)

    nom = _atleast_epsilon(nom)
    dnom_squared = _atleast_epsilon(dnom_squared, eps=EPSILON**2)

    d = 2 / (n_clusters * (n_clusters - 1)) * triu(nom / th.sqrt(dnom_squared))
    return d


class LossTerm:
    required_tensors = []

    def __init__(self, *args, **kwargs):
        pass

    def __call__(self, net, cfg, extra):
        raise NotImplementedError()


class DDC1(LossTerm):
    """
    L_1 loss from DDC
    """
    required_tensors = ["hidden_kernel"]

    def __call__(self, net, cfg, extra):
        return d_cs(net.output, extra["hidden_kernel"], cfg.n_clusters)


class DDC2(LossTerm):
    """
    L_2 loss from DDC
    """
    def __call__(self, net, cfg, extra):
        n = net.output.size(0)
        return 2 / (n * (n - 1)) * triu(net.output @ th.t(net.output))


class DDC2Flipped(LossTerm):
    """
    Flipped version of the L_2 loss from DDC. Used by EAMC
    """

    def __call__(self, net, cfg, extra):
        return 2 / (cfg.n_clusters * (cfg.n_clusters - 1)) * triu(th.t(net.output) @ net.output)


class DDC3(LossTerm):
    """
    L_3 loss from DDC
    """
    required_tensors = ["hidden_kernel"]

    def __init__(self, cfg):
        super().__init__()
        self.eye = th.eye(cfg.n_clusters, device=config.DEVICE)

    def __call__(self, net, cfg, extra):
        m = th.exp(-kernel.cdist(net.output, self.eye))
        return d_cs(m, extra["hidden_kernel"], cfg.n_clusters)



class Alignment(LossTerm):
    large_num = 1e9

    def __init__(self, cfg):

        super().__init__()
        # Select which implementation to use
        if cfg.negative_samples_ratio == -1:
            self._loss_func = self._loss_without_negative_sampling
        else:
            self.eye = th.eye(cfg.n_clusters, device=config.DEVICE)
            self._loss_func = self._loss_with_negative_sampling

        # Set similarity function
        if cfg.contrastive_similarity == "cos":
            self.similarity_func = self._cosine_similarity
        elif cfg.contrastive_similarity == "gauss":
            self.similarity_func = kernel.vector_kernel
        else:
            raise RuntimeError(f"Invalid contrastive similarity: {cfg.contrastive_similarity}")

    @staticmethod
    def _norm(mat):
        return th.nn.functional.normalize(mat, p=2, dim=1)

    @staticmethod
    def get_weight(net):
        w = th.min(th.nn.functional.softmax(net.fusion.weights.detach(), dim=0))
        return w

    @classmethod
    def _normalized_projections(cls, net):
        n = net.projections.size(0) // 2
        h1, h2 = net.projections[:n], net.projections[n:]
        h2 = cls._norm(h2)
        h1 = cls._norm(h1)
        return n, h1, h2

    @classmethod
    def _cosine_similarity(cls, projections):
        h = cls._norm(projections)
        return h @ h.t()

    def _draw_negative_samples(self, net, cfg, v, pos_indices):
        cat = net.output.detach().argmax(dim=1)
        cat = th.cat(v * [cat], dim=0)

        weights = (1 - self.eye[cat])[:, cat[[pos_indices]]].T
        n_negative_samples = int(cfg.negative_samples_ratio * cat.size(0))
        negative_sample_indices = th.multinomial(weights, n_negative_samples, replacement=True)
        if DEBUG_MODE:
            self._check_negative_samples_valid(cat, pos_indices, negative_sample_indices)
        return negative_sample_indices

    @staticmethod
    def _check_negative_samples_valid(cat, pos_indices, neg_indices):
        pos_cats = cat[pos_indices].view(-1, 1)
        neg_cats = cat[neg_indices]
        assert (pos_cats != neg_cats).detach().cpu().numpy().all()

    @staticmethod
    def _get_positive_samples(logits, v, n):
        diagonals = []
        inds = []
        for i in range(1, v):
            diagonal_offset = i * n
            diag_length = (v - i) * n
            _upper = th.diagonal(logits, offset=diagonal_offset)
            _lower = th.diagonal(logits, offset=-1 * diagonal_offset)
            _upper_inds = th.arange(0, diag_length)
            _lower_inds = th.arange(i * n, v * n)
            if DEBUG_MODE:
                assert _upper.size() == _lower.size() == _upper_inds.size() == _lower_inds.size() == (diag_length,)
            diagonals += [_upper, _lower]
            inds += [_upper_inds, _lower_inds]

        pos = th.cat(diagonals, dim=0)
        pos_inds = th.cat(inds, dim=0)
        return pos, pos_inds

    def _loss_with_negative_sampling(self, net, cfg, extra):
        n = net.output.size(0)
        v = len(net.backbone_outputs)
        logits = self.similarity_func(net.projections) / cfg.tau

        pos, pos_inds = self._get_positive_samples(logits, v, n)
        neg_inds = self._draw_negative_samples(net, cfg, v, pos_inds)
        neg = logits[pos_inds.view(-1, 1), neg_inds]

        inputs = th.cat((pos.view(-1, 1), neg), dim=1)
        labels = th.zeros(v * (v - 1) * n, device=config.DEVICE, dtype=th.long)
        loss0 = th.nn.functional.cross_entropy(inputs, labels)
        loss = loss0
        loss *= cfg.c1
        return cfg.delta * loss

    def _loss_without_negative_sampling(self, net, cfg, extra):
        assert len(net.backbone_outputs) == 2, "Contrastive loss without negative sampling only supports 2 views."
        n, h1, h2 = self._normalized_projections(net)

        labels = th.arange(0, n, device=config.DEVICE, dtype=th.long)
        masks = th.eye(n, device=config.DEVICE)

        logits_aa = ((h1 @ h1.t()) / cfg.tau) - masks * self.large_num
        logits_bb = ((h2 @ h2.t()) / cfg.tau) - masks * self.large_num

        logits_ab = (h1 @ h2.t()) / cfg.tau
        logits_ba = (h2 @ h1.t()) / cfg.tau

        loss_a = th.nn.functional.cross_entropy(th.cat((logits_ab, logits_aa), dim=1), labels)
        loss_b = th.nn.functional.cross_entropy(th.cat((logits_ba, logits_bb), dim=1), labels)

        loss = (loss_a + loss_b)

        if cfg.adaptive_contrastive_weight:
            loss *= self.get_weight(net)
        return cfg.delta * loss

    def __call__(self, net, cfg, extra):
        return self._loss_func(net, cfg, extra)


class mi_fused(LossTerm):
    def __init__(self, cfg):
        super().__init__()
    def __call__(self, net, cfg, extra):
        device = th.device("cuda:0" if th.cuda.is_available() else "cpu")
        loss1 = mutual_information(net.backbone_outputs[0], net.fused).to(device) \
                + mutual_information(net.backbone_outputs[1], net.fused).to(device) \
                + mutual_information(net.backbone_outputs[2], net.fused).to(device)
        return loss1 * cfg.c2


class Clu(LossTerm):

    def __init__(self, cfg):
        super().__init__()

    def get_weight(net):
        w = th.min(th.nn.functional.softmax(net.fusion.weights.detach(), dim=0))
        return w

    def __call__(self, net, cfg, extra):
        loss_device = device
        criterion_cluster = contrastive_loss.ClusterLoss(20, 1.0, loss_device).to(
            loss_device)
        loss_cluster = criterion_cluster(net.backbone_ddc01, net.backbone_ddc02)+criterion_cluster(net.backbone_ddc01, net.backbone_ddc03)+criterion_cluster(net.backbone_ddc03, net.backbone_ddc02)

        loss = (1-cfg.c2) * loss_cluster
        return loss

def hidden_kernel(net, cfg):
    return kernel.vector_kernel(net.hidden, cfg.rel_sigma)

class Loss(nn.Module):
    TERM_CLASSES = {
        "ddc_1": DDC1,
        "ddc_2": DDC2,
        "ddc_2_flipped": DDC2Flipped,
        "ddc_3": DDC3,
        "Alignment": Alignment,
        "mi_fused": mi_fused,
        "Clu": Clu,
    }
    EXTRA_FUNCS = {
        "hidden_kernel": hidden_kernel,
    }

    def criterion_ins(self, z, pseudo_label):
        n = 100
        assert n % 2 == 0

        invalid_index = pseudo_label == -1
        mask = th.eq(pseudo_label.view(-1, 1), pseudo_label.view(1, -1)).to(
            device
        )
        mask[invalid_index, :] = False
        mask[:, invalid_index] = False
        mask_eye = th.eye(n).float().to(device)
        mask &= ~(mask_eye.bool())
        mask = mask.float()
        contrast_count = 2
        contrast_feature = z
        anchor_feature = contrast_feature
        anchor_count = contrast_count
        anchor_dot_contrast = th.div(
            th.matmul(anchor_feature, contrast_feature.T), 0.7
        )
        logits_max, _ = th.max(anchor_dot_contrast, dim=1, keepdim=True)
        logits = anchor_dot_contrast - logits_max.detach()
        mask = mask.repeat(anchor_count, contrast_count)
        mask_eye = mask_eye.repeat(anchor_count, contrast_count)
        logits_mask = th.scatter(
            th.ones_like(mask),
            1,
            th.arange(n * anchor_count).view(-1, 1).to(device),
            0,
        )
        logits_mask *= 1 - mask
        mask_eye = mask_eye * logits_mask
        exp_logits = th.exp(logits) * logits_mask
        log_prob = logits - th.log(exp_logits.sum(1, keepdim=True))
        mean_log_prob_pos = (mask_eye * log_prob).sum(1) / mask_eye.sum(1)
        instance_loss = -mean_log_prob_pos
        instance_loss = instance_loss.view(anchor_count, n).mean()
        return instance_loss

    def __init__(self, cfg):
        super().__init__()
        self.cfg = cfg
        self.names = cfg.funcs.split("|")
        self.weights = cfg.weights if cfg.weights is not None else len(self.names) * [1]
        self.terms = []
        for term_name in self.names:
            self.terms.append(self.TERM_CLASSES[term_name](cfg))
        self.required_extras_names = list(set(sum([t.required_tensors for t in self.terms], [])))
    def forward(self, net, ignore_in_total=tuple()):
        extra = {name: self.EXTRA_FUNCS[name](net, self.cfg) for name in self.required_extras_names}
        loss_values = {}
        for name, term, weight in zip(self.names, self.terms, self.weights):
            value = term(net, self.cfg, extra)
            if isinstance(value, dict):
                for key, _value in value.items():
                    loss_values[f"{name}/{key}"] = weight * _value
            else:
                loss_values[name] = weight * value
        loss_values["tot"] = sum([loss_values[k] for k in loss_values.keys() if k not in ignore_in_total])
        return loss_values



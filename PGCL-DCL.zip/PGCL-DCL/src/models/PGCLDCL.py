import torch as th
import torch.nn as nn
import helpers
from lib.loss import Loss
from lib.optimizer import Optimizer
from lib.backbones import Backbones
from lib.fusion import get_fusion_module
from models.clustering_module import DDC
from models.model_base import ModelBase
from models.token_transformer import Attention


class PGCLDCL(ModelBase):
    def __init__(self, cfg):
        super().__init__()

        self.cfg = cfg
        self.output = self.hidden = self.fused = self.backbone_outputs = self.projections = \
            self.backbone_ddc_fused = self.backbone_ddc01 = self.backbone_ddc02 = None
        self.backbones = Backbones(cfg.backbone_configs)
        self.fusion = get_fusion_module(cfg.fusion_config, self.backbones.output_sizes)
        bb_sizes = self.backbones.output_sizes
        assert all([bb_sizes[0] == s for s in bb_sizes]), f"PGCLDCL requires all backbones to have the same " \
                                                          f"output size. Got: {bb_sizes}"
        if cfg.projector_config is None:
            self.projector = nn.Identity()
        else:
            self.projector = Attention()
        self.ddc = DDC(input_dim=self.fusion.output_size, cfg=cfg.cm_config)
        self.loss = Loss(cfg=cfg.loss_config)
        self.apply(helpers.he_init_weights)
        self.optimizer = Optimizer(cfg.optimizer_config, self.parameters())

    def forward(self, views):
        self.backbone_outputs = self.backbones(views)
        self.projections = self.projector(th.cat(self.backbone_outputs, dim=0))
        self.fused = self.fusion(self.backbone_outputs)
        self.backbone_ddc01, _ = self.ddc(self.backbone_outputs[0])
        self.backbone_ddc02, _ = self.ddc(self.backbone_outputs[1])
        self.backbone_ddc03, _ = self.ddc(self.backbone_outputs[2])
        self.output, self.hidden = self.ddc(self.fused)
        return self.output, self.backbone_ddc01, self.backbone_ddc02, self.backbone_ddc03

